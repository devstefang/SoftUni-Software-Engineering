﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _5.BirthdayCelebrations
{
    interface IBirthable
    {
        public string BirthDate { get; set; }
    }
}
