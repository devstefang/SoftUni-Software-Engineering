﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4.WildFarm.Models.Foods
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity) : base(quantity)
        {
        }
    }
}
