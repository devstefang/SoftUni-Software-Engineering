﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _4.WildFarm.Models.Contracts
{
   public interface IFood
    {
        public int Quantity { get;}
    }
}
