﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace _1.GenericBoxofString
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<double> values = new List<double>();
            for (int i = 0; i < n; i++)
            {
                double value = double.Parse(Console.ReadLine());
                values.Add(value);
            }
            Box<double> box = new Box<double>(values);
            double compareValue = double.Parse(Console.ReadLine());
            int count = box.GreaterElementsCount(values, compareValue);
            Console.WriteLine(count);
        }
    }
}
